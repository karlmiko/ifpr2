package com.ifpr.funcionarioProjeto.dao;

import com.ifpr.dao.Dao;
import com.ifpr.funcionarioProjeto.FuncionarioProjeto;

public interface FuncionarioProjetoDao extends Dao<FuncionarioProjeto> {

}

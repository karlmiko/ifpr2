package com.ifpr.projeto.dao;

import com.ifpr.dao.Dao;
import com.ifpr.projeto.Projeto;

public interface ProjetoDao extends Dao<Projeto> {

}

package com.ifpr.pessoa.dao;

import com.ifpr.dao.Dao;
import com.ifpr.pessoa.Pessoa;

public interface PessoaDao extends Dao<Pessoa> {

}
